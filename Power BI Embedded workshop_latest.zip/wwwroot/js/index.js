// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

$(function () {
    var models = window["powerbi-client"].models;
    var reportContainer = $("#report-container").get(0);
    var editReportContainer = $("#edit-report-container").get(0);
    var qnaContainer = $("#qna-container").get(0);
    var embedDatasetId = "6f22f059-088b-40ca-9adf-f285dc9ff2bb"; // This is a hardcoded dataset for embedding Q&A
    $("#exportCsv").hide();

    $.ajax({
        type: "GET",
        url: "/embedinfo/getembedinfo",
        success: function (data) {
            embedParams = $.parseJSON(data);

            // Config to embed report in READ MODE
            reportLoadConfig = {
                type: "report",
                tokenType: models.TokenType.Embed,
                accessToken: embedParams.EmbedToken.Token,
                embedUrl: embedParams.EmbedReport[0].EmbedUrl, // Report embed URL
            };

            // Config to embed report in WRITE MODE
            editReportLoadConfig = {
                type: "report",
                tokenType: models.TokenType.Embed,
                accessToken: embedParams.EmbedToken.Token,
                embedUrl: embedParams.EmbedReport[0].EmbedUrl, // Report embed URL

                // Code to embed report in Edit mode
                permissions: models.Permissions.All,
                viewMode: models.ViewMode.Edit,
            };

            // Config to embed Q&A
            qnaLoadConfig = {
                type: 'qna',
                tokenType: models.TokenType.Embed,
                accessToken: embedParams.EmbedToken.Token,
                embedUrl: "https://app.powerbi.com/qnaEmbed",
                id: embedDatasetId,

                // Code to embed Q&A on dataset
                viewMode: models.QnaMode.Interactive,
                datasetIds: [embedDatasetId]
            };

            // Use the token expiry to regenerate Embed token for seamless end user experience
            // Refer https://aka.ms/RefreshEmbedToken
            tokenExpiry = embedParams.EmbedToken.Expiration;

            // Embed Power BI report/QnA when Access token and Embed URL are available
            var report = powerbi.embed(reportContainer, reportLoadConfig);
            // var editReport = powerbi.embed(editReportContainer, editReportLoadConfig);
            // var qna = powerbi.embed(qnaContainer, qnaLoadConfig)

            // Clear any other loaded handler events
            report.off("loaded");

            // Triggers when a report schema is successfully loaded
            report.on("loaded", function () {
                console.log("Report load successful");
            });

            // Clear any other rendered handler events
            report.off("rendered");

            // Triggers when a report is successfully embedded in UI
            report.on("rendered", function () {
                console.log("Report render successful");
            });

            // Clear any other error handler events
            report.off("error");
            
            // Handle embed errors
            report.on("error", function (event) {
                var errorMsg = event.detail;
            
                // Use errorMsg variable to log error in any destination of choice
                console.error(errorMsg);
                return;
            });

            $("#exportCsv").on("click", async function () {
                let pages = await report.getPages();

                // Retrieve the active page.
                let activePage = pages.filter(function (page) {
                    return page.isActive
                })[0];
                              
                let visuals = await activePage.getVisuals();
                // console.log(visuals);
                let exportVisual = visuals[5]; // visual is hardcoded for export
                let result = await exportVisual.exportData(models.ExportDataType.Summarized, 100);
                
                downloadCsvFile(result.data, exportVisual.title);
            });
        },
        error: function (err) {
            
            // Show error container
            var errorContainer = $(".error-container");
            $(".embed-container").hide();
            errorContainer.show();
            
            // Format error message
            var errMessageHtml = "<strong> Error Details: </strong> <br/>" + err.responseText;
            errMessageHtml = errMessageHtml.split("\n").join("<br/>");

            // Show error message on UI
            errorContainer.append(errMessageHtml);
        }
    });
    
    /**
     * Downloads the file in CSV format
     * @param fileData file JSON object
     */
    function downloadCsvFile (fileData, fileName) {
        let blob = new Blob([fileData], {type: 'text/csv'});

        // Creating an object URL
        const URL = window.URL || window.webkitURL;
        const dataUrl = URL.createObjectURL(blob);

        // Downloading the file using the object URL by using anchor element
        const element = document.createElement('a');
        element.setAttribute('class', 'download-anchor');
        element.setAttribute('href', dataUrl);
        element.setAttribute('download', fileName);
        document.body.appendChild(element);
        element.click();

        // Deleting the object URL and anchor element
        document.body.removeChild(element);
        URL.revokeObjectURL(dataUrl);
    }
});
